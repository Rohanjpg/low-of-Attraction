let Only_My_Lines=0;

// show my lines

document.getElementById("myline").addEventListener('click',()=>{
    Only_My_Lines=1;

    save()
    Next()

    readJoke()
})

let M=0;

// for next button in manual
function run_manual(){
    if(M <= textArray.length){
        let jokeElement2 = textArray[M];  // Get the joke at the current index
        document.getElementById("joke").value = jokeElement2;
    M++
    }    
    else{
        alert("(no data) Please Add Your Lines")
        M = 0;
       
    }
}

// SHOW GERNAL LINES

document.getElementById("Gernal-Lines").addEventListener('click', () => {
    Only_My_Lines=0;
    Next();
    readJoke();
});