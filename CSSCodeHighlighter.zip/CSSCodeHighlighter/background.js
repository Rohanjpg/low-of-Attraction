chrome.runtime.onInstalled.addListener(() => {
    console.log('Law of Attraction');
  });
  