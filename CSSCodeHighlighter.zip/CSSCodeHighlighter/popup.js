const jokeElement = document.getElementById('joke');
const newJokeButton = document.getElementById('new-joke');
const backJokeButton = document.getElementById('back-joke'); 

function save() {
  let saveshow = document.getElementById("saveshow");
  saveshow.innerHTML = "Saved";
  saveshow.style.display = 'block';

  // Hide the "Saved" message after 2 seconds
  setTimeout(() => {
      saveshow.style.display = 'none';
  }, 2000);
}

  const motivational = [
    "You attract what you believe, not just what you want.",
    "Your thoughts are seeds. Plant positivity and watch your dreams grow.",
    "The universe responds to the frequency you emit, so make it love.",
    "Your desires are a reflection of your potential—believe in them.",
    "What you focus on expands, so choose to focus on abundance.",
    "Every thought you think is a vibration that echoes into the universe.",
    "You are worthy of everything you are manifesting.",
    "What you seek is seeking you, so stay open and ready to receive.",
    "The law of attraction doesn’t ask for perfection—just faith in your dreams.",
    "Your energy introduces you before you even speak—let it radiate positivity.",
    "Thoughts become things. Choose the good ones.",
    "Believe in your power to manifest your dreams into reality.",
    "The universe always has your back when you align with your true desires.",
    "Your mind is a magnet. What you think, you attract.",
    "What you think, you become. So, think big and think positive.",
    "The more you align with your inner truth, the more the universe will work in your favor.",
    "The universe is conspiring in your favor. Trust the process.",
    "Abundance flows to me effortlessly and continuously.",
    "You are the creator of your reality, so create something beautiful.",
    "Everything you want is already on its way to you.",
    "Like attracts like. Be the energy you want to attract.",
    "Your reality is a reflection of your thoughts—shift them and shift your life.",
    "Your dream life begins the moment you believe in it.",
    "Focus on what you want, not on what you don't want.",
    "The law of attraction is always working—choose thoughts that support your goals.",
    "Visualize your success, and the universe will help you manifest it.",
    "The key to attracting abundance is gratitude for the present moment.",
    "You are a magnet for success and good fortune.",
    "All that you need is already within you. Believe it, and it will manifest.",
    "Manifesting begins with a single thought. Choose wisely.",
    "The universe gives you what you believe you deserve.",
    "Let go of fear and trust in the process of manifestation.",
    "Your mind is your most powerful tool—use it to create your ideal life.",
    "When you align with your true desires, everything falls into place.",
    "The universe doesn't respond to words; it responds to energy.",
    "You are capable of manifesting your wildest dreams.",
    "Every step you take toward your dream is a step closer to manifestation.",
    "Gratitude is the fastest way to manifest your desires.",
    "Let your dreams be bigger than your fears, and your actions louder than your words.",
    "You are worthy of everything you desire, so act as if it's already yours.",
    "Be patient, the universe is working behind the scenes.",
    "The more you focus on what you want, the quicker it will manifest.",
    "Believe it is possible, and the universe will help you make it happen.",
    "Your energy will always attract the right people and situations.",
    "What you focus on, you create more of. Choose wisely.",
    "The law of attraction is not just about thinking; it's about feeling.",
    "You attract not what you want, but what you are.",
    "Success is inevitable when you believe in your potential.",
    "Every thought is a powerful force in shaping your reality.",
    "The universe works in mysterious ways to bring your desires to you.",
    "Start each day with the intention to manifest your dreams.",
    "What you believe is what you receive—choose abundance and success.",
    "You are worthy of everything you want in life. Don't settle for less.",
    "Your thoughts shape your future, so think positively and dream big.",
    "When you focus on the good, the good gets better.",
    "You have the power to manifest everything you desire.",
    "The more grateful you are, the more you attract into your life.",
    "When you ask the universe for something, trust that it is already on its way.",
    "Your thoughts are energy—choose thoughts that fuel your dreams.",
    "Abundance is your natural state—allow it to flow freely into your life.",
    "You are a divine creator of your reality. Trust in your power.",
    "You have the ability to create the life of your dreams, one thought at a time.",
    "The universe is always listening to your vibrations.",
    "Your inner world creates your outer world—choose your thoughts wisely.",
    "The universe has an infinite supply of abundance waiting for you.",
    "Believe in your own power, and the universe will believe in you too.",
    "Every moment is an opportunity to align with your desires.",
    "You attract experiences that match your vibrational frequency.",
    "The law of attraction brings you what you focus on with intention.",
    "You have the power to create the life you’ve always dreamed of.",
    "Trust that the universe is guiding you to your highest good.",
    "Your thoughts create your reality, so choose positivity every day.",
    "The universe always says yes to the energy you put out.",
    "Manifestation is not about control—it's about allowing.",
    "You can have, be, or do anything you want—just believe it is possible.",
    "The universe is abundant, and it is your birthright to receive it.",
    "What you think and feel right now is creating your tomorrow.",
    "Everything you need is already within you—tap into your inner power.",
    "When you focus on what you love, the universe will send you more of it.",
    "Thoughts are energy, and energy creates reality.",
    "Trust in the timing of the universe and everything will unfold perfectly.",
    "Manifestation requires patience, but it always comes at the right time.",
    "The law of attraction works in your favor—trust the process.",
    "Your dream life is already unfolding before you. Stay focused.",
    "The universe doesn't make mistakes—everything is part of the plan.",
    "You are worthy of receiving everything you desire and more.",
    "Start each day with gratitude, and watch your dreams come to life.",
    "Your vibrational energy attracts similar energy—keep it positive.",
    "Believe in the impossible, and watch the universe make it possible.",
    "When you align your energy with your desires, everything becomes possible.",
    "The universe will always give you exactly what you believe you deserve.",
    "Abundance is attracted to gratitude—be thankful for what you have.",
    "When you release doubt, you open the door to limitless possibilities.",
    "Focus on the present moment, for it is where your power lies.",
    "The universe is a mirror—it reflects what you project.",
    "You are a magnet for what you focus on. Choose wisely.",
    "Your thoughts today will create your tomorrow.",
    "Trust that your desires are on their way to you.",
    "Abundance flows freely when you align with the energy of gratitude.",
    "Manifestation is a journey—enjoy the process and trust in the outcome.",
    "When you let go of fear and doubt, you make space for miracles.",
    "The universe has an abundance of everything you desire. Open your heart to it.",
    "Your thoughts are the blueprint of your future. Build wisely.",
    "Everything you seek is seeking you. Trust the process.",
    "The law of attraction is a reflection of the energy you put out.",
    "You are a powerful creator. Your dreams are within reach.",
    "What you ask for, you receive—stay clear in your intentions.",
    "When you believe it, the universe will deliver it.",
    "Manifest your desires by aligning your thoughts, feelings, and actions.",
    "The law of attraction brings into your life what you focus on most.",
    "You are deserving of the very best. Don't settle for anything less.",
    "Every thought you think sends out a vibration to the universe.",
    "The universe is always working with you, not against you.",
    "Abundance is everywhere, waiting for you to recognize it.",
    "Your mind is your greatest asset—use it to create your dream life.",
    "Dream big, believe in yourself, and watch the universe bring your dreams to life."
  ];

  let currentIndex = 0;

  function Next() {
    // If "Only My Lines" is enabled, show user-added lines
    if (Only_My_Lines === 1) {
        if (textArray.length > 0) {
            jokeElement.value = textArray[currentIndex];
            currentIndex = (currentIndex + 1) % textArray.length;  // Loop through user lines
           
        } else {
            jokeElement.value = "No lines available.";  // No user-added lines
            
        }
    } else {
        if (motivational.length > 0) {
            jokeElement.value = motivational[currentIndex];
            currentIndex = (currentIndex + 1) % motivational.length;  // Loop through general lines
            
        } else {
            jokeElement.value = "No general lines available.";  // No general quotes
            
        }
    }
    
}

// Function to go to the previous quote
function back() {
    // If "Only My Lines" is enabled, use user-added lines
    if (Only_My_Lines === 1) {
        if (textArray.length > 0) {
            currentIndex = (currentIndex - 1 + textArray.length) % textArray.length;  // Loop through user lines in reverse
            jokeElement.value = textArray[currentIndex];
            
        } else {
            jokeElement.value = "No lines available.";  // No user-added lines
            
        }
    } else {
        // Use general motivational quotes
        if (motivational.length > 0) {
            if (currentIndex > 0) {
                currentIndex--;  // Move to the previous quote
                
            } else {
                currentIndex = motivational.length - 1;  // If at the start, go to the last quote
            }
            jokeElement.value = motivational[currentIndex];
        } else {
            jokeElement.value = "No general lines available.";  // No general quotes

           
        }
    }
    
}

// Initialize the display with the first joke or line
Next();

// Next Button Event Listener
newJokeButton.addEventListener('click', Next);

// Back Button Event Listener
backJokeButton.addEventListener('click', back);


