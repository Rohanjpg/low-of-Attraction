

// show add line input box

let addline = document.getElementById('add');
// let addline2=document.getElementById('addButton');
addline.addEventListener('click', () => {
  // Get the input element
  let inputElement = document.getElementById('input');
  let inputElement2 = document.getElementById('addButton');
  // Toggle the display of the input element
  inputElement.style.display = (inputElement.style.display === "none" || inputElement.style.display === "") ? "block" : "none";
  inputElement2.style.display = (inputElement2.style.display === "none" || inputElement2.style.display === "") ? "block" : "none";

});



// manuall add text 

let manualcount=0;

  // Initialize an empty array to store the user's input
  let textArray = [];

  // Get the elements by their new IDs
  const input = document.getElementById('input');
  const addButton = document.getElementById('addButton');

  // Retrieve any previously saved data from localStorage
  if (localStorage.getItem('textArray')) {
      textArray = JSON.parse(localStorage.getItem('textArray')); // Parse the saved data
  }

  // Function to save textArray to localStorage
  function saveToLocalStorage() {
      localStorage.setItem('textArray', JSON.stringify(textArray)); // Convert array to string and save
  }

  // Function to add text to the array
  addButton.addEventListener('click', () => {
      // Get the text entered by the user
      const inputText = input.value.trim();

      // Check if the input is not empty
      if (inputText) {
          // Add the input text to the array
          textArray.push(inputText);

          // Save the updated array to localStorage
          saveToLocalStorage();

          // Clear the input field for the next entry
          input.value = '';         

      } else {
          alert("Please enter some text!");
      }
  });


//   clean manual  data


document.getElementById("delete-data").addEventListener('click', () => {
    // Clear all data from localStorage
    localStorage.clear();

    // Reset Only_My_Lines to 0 (General lines mode)
    Only_My_Lines = 0;

    // Reset textArray to an empty array
    textArray = [];

    // Call the Next function to show the next item (based on the updated state)
    Next();

    // Call the save function to show the "Saved" message
    save();

    readJoke()
});


