// Get the joke element


// Get the "Read Joke" button element
const readJokeButton = document.getElementById('read-joke'); // Get the "Read Joke" button
        const voiceSelect = document.getElementById('voice-select'); 

        let voices = []; // Store the voices

        function loadVoices() {
            voices = speechSynthesis.getVoices(); // Get available voices
            console.log("Available voices: ", voices); // Log voices for debugging

            // Clear the dropdown options before adding new ones
            voiceSelect.innerHTML = '';

            // Find the first Hindi voice (if available)
            let hindiVoice = voices.find(voice => voice.lang.includes('hi')); // Find Hindi voice
            if (hindiVoice) {
                // Add the Hindi voice first in the dropdown
                const hindiOption = document.createElement('option');
                hindiOption.value = hindiVoice.name;
                hindiOption.textContent = `Hindi - ${hindiVoice.name}`;
                voiceSelect.appendChild(hindiOption);
            }

            // Populate the dropdown with other available voices
            voices.forEach(voice => {
                if (voice.lang !== 'hi') { // Skip Hindi voices as we added them already
                    const option = document.createElement('option');
                    option.value = voice.name;
                    option.textContent = voice.name;
                    voiceSelect.appendChild(option);
                }
            });

            // Set the default voice to the Hindi voice (if found)
            if (hindiVoice) {
                voiceSelect.value = hindiVoice.name;
            } else if (voices.length > 0) {
                // Default to the first available voice if no Hindi voice is found
                voiceSelect.value = voices[0].name;
            }
        }

        // Function to read the joke aloud
        function readJoke() {
            const jokeText = jokeElement.value.trim(); // Get the text content of the joke element

            // If there is text to read
            if (jokeText !== "") {
                const utterance = new SpeechSynthesisUtterance(jokeText); // Create a new SpeechSynthesisUtterance object

                // Find the selected voice from the dropdown
                const selectedVoiceName = voiceSelect.value;
                const selectedVoice = voices.find(voice => voice.name === selectedVoiceName);

                if (selectedVoice) {
                    utterance.voice = selectedVoice; // Use the selected voice
                } else {
                    utterance.voice = voices[0]; // Fallback to the first available voice
                    console.warn("Selected voice not found, using default.");
                }

                // Adjust speech parameters to make it sound more natural
                utterance.rate = 1;  // Speed of the voice
                utterance.pitch = 1; // Natural pitch
                utterance.volume = 0.7;  // Volume level (0 to 1)

                // Speak the text aloud
                window.speechSynthesis.speak(utterance);
            } else {
                alert("Please enter some text to read.");
            }
        }

        // Add event listener for "Read Joke" button
        readJokeButton.addEventListener('click', readJoke);

        // Load voices when page loads or on voices changed
        if (speechSynthesis.onvoiceschanged !== undefined) {
            speechSynthesis.onvoiceschanged = loadVoices; // For browsers that support dynamic voices
        } else {
            loadVoices(); // If the browser loads voices immediately, load them here
        }